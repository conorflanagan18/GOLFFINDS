# ⛳ TeeTimeFinds – Curated Golf Deals

TeeTimeFinds is a responsive, public-facing website that displays curated golf product deals organized by category. The goal is to provide easy access to quality affiliate links with a clean and user-friendly interface.

![TeeTimeFinds Preview](assets/golf_deal_ai_sample.jpg)

## 🔍 Features

- 🛒 **Product Grid** — Displays golf products with name, price, description, and a direct "View Deal" link.
- 🎯 **Filter Bar** — Easily filter products by categories like Clubs, Tech, Balls, and more.
- 📱 **Responsive Design** — Mobile- and desktop-friendly.
- 📸 **Visuals** — AI-generated or sourced product images integrated for a polished look.

## 📂 Folder Structure

```
teetimefinds/
├── index.html
├── README.md
├── assets/
│   └── golf_deal_ai_sample.jpg
```

## 🚀 How to Deploy (GitHub Pages)

1. Push this project to your GitHub repository.
2. Go to **Settings → Pages**.
3. Under **Source**, choose `main` branch and `/root`.
4. Click **Save**. Your site will be live at:
   ```
   https://<your-github-username>.github.io/<repo-name>/
   ```

## 🙌 Built With

- HTML5 + CSS3
- Vanilla JavaScript
- Responsive CSS Grid

---
